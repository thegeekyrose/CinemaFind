"""
bak_reader.py - cititor READ-ONLY pentru backup-uri SQL Server (.bak, necomprimate).
Fisierul este deschis doar in modul 'rb'; nu se scrie nimic in el.
Parseaza paginile de date de 8 KB, reconstruieste schema din syscolpars/sysschobjs
si returneaza tabelele utilizator ca liste de dictionare.
"""
import struct, datetime, uuid, collections

PAGE = 8192
TYPES = {56:'int',52:'smallint',48:'tinyint',127:'bigint',104:'bit',231:'nvarchar',167:'varchar',
         175:'char',239:'nchar',61:'datetime',58:'smalldatetime',106:'decimal',108:'numeric',
         62:'float',59:'real',36:'uniqueidentifier',40:'date',42:'datetime2',41:'time',43:'datetimeoffset',
         34:'image',35:'text',99:'ntext',165:'varbinary',173:'binary',60:'money',122:'smallmoney',189:'timestamp'}
FIXED = {'int':4,'smallint':2,'tinyint':1,'bigint':8,'bit':1,'datetime':8,'smalldatetime':4,'float':8,
         'real':4,'uniqueidentifier':16,'date':3,'money':8,'smallmoney':4,'timestamp':8}

def load_pages(path):
    pages = {}
    with open(path, 'rb') as f:          # READ ONLY
        d = f.read()
    for o in range(0, len(d) - PAGE + 1, 512):
        if d[o] == 1 and d[o+1] in (1,2,3,10,11,13,15,16,17,18,19) and struct.unpack_from('<H', d, o+36)[0] == 1:
            pn = struct.unpack_from('<I', d, o+32)[0]
            pages[pn] = d[o:o+PAGE]
    return pages

def records(page):
    cnt = struct.unpack_from('<H', page, 22)[0]
    for i in range(cnt):
        off = struct.unpack_from('<H', page, PAGE - 2*(i+1))[0]
        if 96 <= off < PAGE: yield off

def decode(col, raw):
    t = col['type']
    if raw is None: return None
    if t == 'int': return struct.unpack('<i', raw)[0]
    if t == 'smallint': return struct.unpack('<h', raw)[0]
    if t == 'tinyint': return raw[0]
    if t == 'bigint': return struct.unpack('<q', raw)[0]
    if t == 'bit': return bool(raw[0] & 1)
    if t == 'float': return struct.unpack('<d', raw)[0]
    if t == 'real': return struct.unpack('<f', raw)[0]
    if t == 'uniqueidentifier': return str(uuid.UUID(bytes_le=raw))
    if t == 'datetime':
        ticks, days = struct.unpack('<Ii', raw)
        return (datetime.datetime(1900,1,1) + datetime.timedelta(days=days, seconds=ticks/300)).isoformat(sep=' ')
    if t == 'smalldatetime':
        m, days = struct.unpack('<HH', raw)
        return (datetime.datetime(1900,1,1) + datetime.timedelta(days=days, minutes=m)).isoformat(sep=' ')
    if t == 'date':
        return (datetime.date(1,1,1) + datetime.timedelta(days=int.from_bytes(raw,'little'))).isoformat()
    if t in ('datetime2', 'datetimeoffset'):
        tl = len(raw) - 3 - (2 if t == 'datetimeoffset' else 0)
        ticks = int.from_bytes(raw[:tl], 'little'); sc = col['scale']
        days = int.from_bytes(raw[tl:tl+3], 'little')
        return (datetime.datetime(1,1,1) + datetime.timedelta(days=days, seconds=ticks / (10 ** sc))).isoformat(sep=' ')
    if t in ('nvarchar','nchar','ntext'): return raw.decode('utf-16le', 'replace')
    if t in ('varchar','char','text'): return raw.decode('cp1252', 'replace')
    if t in ('decimal','numeric'):
        sign = raw[0]; v = int.from_bytes(raw[1:], 'little')
        v = v / (10 ** col['scale']); return v if sign == 1 else -v
    if t == 'money': return struct.unpack('<q', raw)[0] / 10000
    return raw.hex()

def parse_record(page, off, cols):
    """cols: lista de coloane ordonata dupa colid. Returneaza dict sau None."""
    status = page[off]
    rtype = (status >> 1) & 7
    if rtype != 0: return None                      # doar inregistrari primare (nu ghost/forwarded)
    fixlen_end = struct.unpack_from('<H', page, off+2)[0]
    fixed = [c for c in cols if c['type'] in FIXED or c['type'] in ('datetime2','datetimeoffset') or (c['type'] in ('decimal','numeric','char','nchar','binary') )]
    var = [c for c in cols if c not in fixed]
    p = off + 4
    row = {}
    for c in fixed:
        if c['type'] in FIXED: ln = FIXED[c['type']]
        elif c['type'] == 'datetime2': ln = 6 if c['scale'] <= 2 else 7 if c['scale'] <= 4 else 8
        elif c['type'] == 'datetimeoffset': ln = (6 if c['scale'] <= 2 else 7 if c['scale'] <= 4 else 8) + 2
        elif c['type'] in ('decimal','numeric'): ln = {1:5,2:9,3:9,4:9,5:9,6:9,7:9,8:9,9:9}.get(1) if False else (5 if c['prec']<=9 else 9 if c['prec']<=19 else 13 if c['prec']<=28 else 17)
        else: ln = c['length'] // (2 if c['type']=='nchar' else 1)*(2 if c['type']=='nchar' else 1)
        row[c['name']] = ('F', page[p:p+ln]); p += ln
    if p != off + fixlen_end: return None
    ncols = struct.unpack_from('<H', page, p)[0]; p += 2
    nb = (ncols + 7)//8
    bitmap = page[p:p+nb]; p += nb
    out = {}
    idx = 0
    for c in fixed:
        isnull = (bitmap[idx//8] >> (idx % 8)) & 1 if idx < ncols else 1
        out[c['name']] = None if isnull else decode(c, row[c['name']][1]); idx += 1
    nvar = 0
    if status & 0x20:                               # are coloane variabile
        nvar = struct.unpack_from('<H', page, p)[0]; p += 2
        offs = struct.unpack_from('<%dH' % nvar, page, p); p += 2*nvar
        start = p
        for i, c in enumerate(var):
            isnull = (bitmap[idx//8] >> (idx % 8)) & 1 if idx < ncols else 1
            idx += 1
            if i >= nvar or isnull: out[c['name']] = None; continue
            end = off + (offs[i] & 0x7FFF)
            raw = page[start:end]
            out[c['name']] = decode(c, raw)
            start = end
    else:
        for c in var: out[c['name']] = None
    return out

SYS_COLPARS = [dict(name=n,type=t,length=l,prec=0,scale=0) for n,t,l in [
    ('id','int',4),('number','smallint',2),('colid','int',4),('xtype','tinyint',1),('utype','int',4),
    ('length','smallint',2),('prec','tinyint',1),('scale','tinyint',1),('collationid','int',4),
    ('status','int',4),('maxinrow','smallint',2),('xmlns','int',4),('dflt','int',4),('chk','int',4),
    ('name','nvarchar',256),('idtval','varbinary',0)]]
# ordinea fizica: fixed in ordinea definitiei, apoi variabile (name, idtval)
SYS_SCHOBJS = [dict(name=n,type=t,length=l,prec=0,scale=0) for n,t,l in [
    ('id','int',4),('name','nvarchar',256),('nsid','int',4),('nsclass','tinyint',1),('status','int',4),
    ('type','char',2),('pid','int',4),('pclass','tinyint',1),('intprop','int',4),
    ('created','datetime',8),('modified','datetime',8),('status2','int',4)]]

def read_database(path):
    pages = load_pages(path)
    # pagina -> (object id real, index id) prin sysallocunits (7) -> sysrowsets (5)
    sysp = collections.defaultdict(list)
    for pn, pg in sorted(pages.items()):
        if pg[1] == 1: sysp[struct.unpack_from('<I', pg, 24)[0]].append(pg)
    rowset_obj = {}
    for pg in sysp.get(5, []):
        for off in records(pg):
            if pg[off] & 0x0E: continue
            rid, = struct.unpack_from('<q', pg, off+4)
            idmajor, idminor = struct.unpack_from('<ii', pg, off+13)
            rowset_obj[rid] = (idmajor, idminor)
    idobj_to_table = {}
    for pg in sysp.get(7, []):
        for off in records(pg):
            if pg[off] & 0x0E: continue
            auid, = struct.unpack_from('<q', pg, off+4)
            owner, = struct.unpack_from('<q', pg, off+13)
            if owner in rowset_obj: idobj_to_table[(auid >> 16) & 0xFFFFFFFF] = rowset_obj[owner]
    byobj = collections.defaultdict(list)
    for pn, pg in sorted(pages.items()):
        if pg[1] != 1: continue
        k = struct.unpack_from('<I', pg, 24)[0]
        if k in (34, 41): byobj[k].append(pg)          # sysschobjs / syscolpars (id-uri fixe)
        elif k in idobj_to_table:
            oid, ind = idobj_to_table[k]
            if ind in (0, 1) and oid > 255: byobj[oid].append(pg)
    objs = {}
    for pg in byobj.get(34, []):
        for off in records(pg):
            try: r = parse_record(pg, off, SYS_SCHOBJS)
            except Exception: r = None
            if r and r['type'] and r['type'].strip() == 'U': objs[r['id']] = r['name']
    colsby = collections.defaultdict(list)
    for pg in byobj.get(41, []):
        for off in records(pg):
            try: r = parse_record(pg, off, SYS_COLPARS)
            except Exception: r = None
            if r and r['id'] in objs and r['xtype'] in TYPES:
                colsby[r['id']].append(dict(name=r['name'], colid=r['colid'], type=TYPES[r['xtype']],
                                            length=r['length'], prec=r['prec'], scale=r['scale']))
    db = {}
    for oid, name in objs.items():
        cols = sorted(colsby.get(oid, []), key=lambda c: c['colid'])
        rows = []
        for pg in byobj.get(oid, []):
            for off in records(pg):
                try: r = parse_record(pg, off, cols)
                except Exception: r = None
                if r: rows.append(r)
        db[name] = dict(columns=[(c['name'], c['type']) for c in cols], rows=rows)
    return db

if __name__ == '__main__':
    import sys
    db = read_database(sys.argv[1])
    for t, v in db.items():
        print(t, len(v['rows']), v['columns'])
