"""Algoritmi implementati de la zero (fara biblioteci externe): DBSCAN, Apriori, ID3."""
import math, itertools
from collections import Counter, defaultdict

# ------------------------------------------------------------------ DBSCAN
def dbscan(points, eps, min_pts, dist=None):
    """points: lista de vectori. Returneaza etichete: 0..k-1 = cluster, -1 = zgomot."""
    dist = dist or (lambda a, b: math.dist(a, b))
    n = len(points); labels = [None] * n; cid = 0
    nb = lambda i: [j for j in range(n) if dist(points[i], points[j]) <= eps]
    for i in range(n):
        if labels[i] is not None: continue
        N = nb(i)
        if len(N) < min_pts: labels[i] = -1; continue
        labels[i] = cid; seeds = [j for j in N if j != i]
        while seeds:
            j = seeds.pop()
            if labels[j] == -1: labels[j] = cid          # punct de granita
            if labels[j] is not None: continue
            labels[j] = cid
            Nj = nb(j)
            if len(Nj) >= min_pts: seeds.extend(Nj)      # punct nucleu -> extinde
        cid += 1
    return labels

# ------------------------------------------------------------------ Apriori
def apriori(transactions, min_support, min_conf, max_len=3):
    """Returneaza (itemseturi_frecvente{frozenset:support}, reguli[dict])."""
    T = [frozenset(t) for t in transactions]; N = len(T)
    sup = lambda s: sum(1 for t in T if s <= t) / N
    items = {i for t in T for i in t}
    freq = {}
    L = {frozenset([i]): sup(frozenset([i])) for i in items}
    L = {s: v for s, v in L.items() if v >= min_support}
    k = 1
    while L:
        freq.update(L)
        if k >= max_len: break
        keys = list(L); cand = set()
        for a, b in itertools.combinations(keys, 2):      # generare candidati (join)
            u = a | b
            if len(u) == k + 1 and all(frozenset(s) in L for s in itertools.combinations(u, k)):  # prune
                cand.add(u)
        L = {c: sup(c) for c in cand}; L = {s: v for s, v in L.items() if v >= min_support}
        k += 1
    rules = []
    for s, sv in freq.items():
        if len(s) < 2: continue
        for r in range(1, len(s)):
            for ant in map(frozenset, itertools.combinations(s, r)):
                cons = s - ant; conf = sv / freq[ant]
                if conf >= min_conf:
                    rules.append(dict(antecedent=sorted(ant), consequent=sorted(cons), support=sv,
                                      confidence=conf, lift=conf / freq[cons]))
    rules.sort(key=lambda r: (-r['lift'], -r['confidence']))
    return freq, rules

# ------------------------------------------------------------------ ID3
def entropy(labels):
    n = len(labels)
    return -sum(c / n * math.log2(c / n) for c in Counter(labels).values()) if n else 0.0

def info_gain(rows, labels, feat):
    groups = defaultdict(list)
    for r, y in zip(rows, labels): groups[r[feat]].append(y)
    rem = sum(len(g) / len(labels) * entropy(g) for g in groups.values())
    return entropy(labels) - rem

class ID3:
    """Arbore de decizie ID3 pentru atribute categoriale (castig informational / entropie)."""
    def __init__(self, max_depth=4, min_samples=4): self.max_depth, self.min_samples, self.tree = max_depth, min_samples, None
    def fit(self, rows, labels, features=None):
        self.features = features or list(rows[0])
        self.tree = self._build(rows, labels, list(self.features), 0)
        return self
    def _leaf(self, labels):
        c = Counter(labels); p = (c.get(1, 0) + 1) / (len(labels) + 2)   # Laplace
        return dict(leaf=True, label=1 if c.get(1, 0) >= c.get(0, 0) else 0, p=p, n=len(labels))
    def _build(self, rows, labels, feats, depth):
        if len(set(labels)) == 1 or not feats or depth >= self.max_depth or len(labels) < self.min_samples:
            return self._leaf(labels)
        gains = {f: info_gain(rows, labels, f) for f in feats}
        best = max(gains, key=gains.get)
        if gains[best] <= 1e-9: return self._leaf(labels)
        node = dict(leaf=False, feat=best, gain=gains[best], default=self._leaf(labels), kids={})
        for v in {r[best] for r in rows}:
            idx = [i for i, r in enumerate(rows) if r[best] == v]
            node['kids'][v] = self._build([rows[i] for i in idx], [labels[i] for i in idx],
                                          [f for f in feats if f != best], depth + 1)
        return node
    def predict_proba(self, row):
        n = self.tree
        while not n['leaf']:
            n = n['kids'].get(row.get(n['feat']), n['default'])
        return n['p']
    def explain(self, row):
        n, path = self.tree, []
        while not n['leaf']:
            v = row.get(n['feat']); path.append(f"{n['feat']}={v}")
            if v not in n['kids']: n = n['default']; break
            n = n['kids'][v]
        return path
    def dump(self, node=None, ind=0):
        node = node or self.tree; pad = '  ' * ind
        if node['leaf']: return f"{pad}-> {'PLACE' if node['label'] else 'NU place'} (p={node['p']:.2f}, n={node['n']})\n"
        s = ''
        for v, k in sorted(node['kids'].items(), key=lambda kv: str(kv[0])):
            s += f"{pad}[{node['feat']} = {v}] (castig {node['gain']:.3f})\n" + self.dump(k, ind + 1)
        return s
