"""Server web (stdlib): python server.py  ->  http://localhost:8000"""
import json, os, sqlite3, sys
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from recommender import Engine, DB

E = Engine(); EVAL = None
ROOT = os.path.dirname(os.path.abspath(__file__))

def films_query(q):
    g = lambda k, d='': q.get(k, [d])[0]
    u = g('user'); text = g('q').lower(); genre = g('genre')
    ymin, ymax = int(g('year_min', 0) or 0), int(g('year_max', 9999) or 9999)
    stats = {}
    for f in E.films:
        sc = [E.rating[x][f] for x in E.rating if f in E.rating[x]]
        stats[f] = (round(sum(sc) / len(sc), 2) if sc else 0, sum(1 for x in E.viewed if f in E.viewed[x]))
    out = []
    for f in E.films.values():
        if text and text not in f['title'].lower() and text not in (f['synopsis'] or '').lower(): continue
        if genre and genre not in f['genres']: continue
        if not ymin <= f['year'] <= ymax: continue
        avg, views = stats[f['id']]
        out.append(dict(f, avg=avg, views=views, my_rating=E.rating[u].get(f['id']) if u else None,
                        seen=(f['id'] in E.viewed[u]) if u else False))
    key = {'title': lambda f: f['title'].lower(), 'year': lambda f: f['year'], 'runtime': lambda f: f['runtime'],
           'avg': lambda f: f['avg'], 'views': lambda f: f['views']}.get(g('sort', 'title'))
    out.sort(key=key, reverse=g('order', 'asc') == 'desc')
    return out

class H(BaseHTTPRequestHandler):
    def send(self, obj, code=200, ctype='application/json'):
        body = obj if isinstance(obj, bytes) else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(code); self.send_header('Content-Type', ctype + '; charset=utf-8')
        self.send_header('Content-Length', str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, *a): pass
    def do_GET(self):
        global EVAL
        p = urlparse(self.path); q = parse_qs(p.query); u = q.get('user', [''])[0]
        if p.path in ('/', '/index.html'):
            return self.send(open(os.path.join(ROOT, 'static', 'index.html'), 'rb').read(), ctype='text/html')
        if p.path == '/api/users':
            return self.send([dict(E.users[x], cluster=E.labels[x], n_views=len(E.viewed[x])) for x in E.uids])
        if p.path == '/api/genres': return self.send(sorted(E.genres.values()))
        if p.path == '/api/films': return self.send(films_query(q))
        if p.path == '/api/history':
            c = E.conn(); rows = [dict(r) for r in c.execute(
                "SELECT h.FilmId,f.Title,h.ViewedAt,h.Progress,h.Completed,r.Score FROM ViewingHistories h JOIN Films f ON f.Id=h.FilmId "
                "LEFT JOIN UserRatings r ON r.UserId=h.UserId AND r.FilmId=h.FilmId WHERE h.UserId=? ORDER BY h.ViewedAt DESC", (u,))]
            c.close(); return self.send(rows)
        if p.path == '/api/recommend' and u in E.users: return self.send(E.recommend(u, int(q.get('k', ['10'])[0])))
        if p.path == '/api/tree' and u in E.users:
            t = E.tree(u); return self.send(dict(tree=t.dump() if t else 'Istoric insuficient pentru ID3.'))
        if p.path == '/api/info':
            if EVAL is None: EVAL = E.evaluate()
            return self.send(dict(E.info(), evaluation=EVAL, params=dict(eps=0.10)))
        self.send({'error': 'not found'}, 404)
    def do_POST(self):
        global EVAL
        if self.path == '/api/rate':
            d = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            u, f, s = d['user'], int(d['film']), int(d['score'])
            if u not in E.users or f not in E.films or not 1 <= s <= 5: return self.send({'error': 'invalid'}, 400)
            c = sqlite3.connect(DB)          # scrie DOAR in baza de lucru SQLite, nu in .bak
            c.execute("INSERT OR REPLACE INTO UserRatings(UserId,FilmId,Score,RatedAt) VALUES(?,?,?,date('now'))", (u, f, s))
            if f not in E.viewed[u]:
                c.execute("INSERT INTO ViewingHistories(UserId,FilmId,ViewedAt,Progress,Completed) VALUES(?,?,date('now'),100,1)", (u, f))
            c.commit(); c.close(); E.load(); E.fit(); EVAL = None
            return self.send({'ok': True})
        self.send({'error': 'not found'}, 404)

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    print(f"CinemaFind pe http://localhost:{port}"); ThreadingHTTPServer(('0.0.0.0', port), H).serve_forever()
