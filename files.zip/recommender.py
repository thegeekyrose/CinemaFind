"""Mecanism de recomandare: DBSCAN (utilizatori similari) + Apriori (asocieri) -> candidati -> ID3 (clasificare) -> scor final."""
import sqlite3, os, math
from collections import defaultdict, Counter
from algorithms import dbscan, apriori, ID3

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cinemafind_work.db')
LIKE = 4                       # rating >= 4  =>  "place"
EPS, MIN_PTS = 0.10, 4         # DBSCAN
MIN_SUP, MIN_CONF, MIN_LIFT = 0.12, 0.70, 1.60  # Apriori
W_ID3, W_APR, W_CLU = 0.45, 0.30, 0.25

class Engine:
    def __init__(self, path=DB):
        self.path = path; self.load(); self.fit()

    def conn(self):
        c = sqlite3.connect(self.path); c.row_factory = sqlite3.Row; return c

    # ---------- date
    def load(self):
        c = self.conn()
        self.genres = {r['Id']: r['Name'] for r in c.execute("SELECT * FROM Genres")}
        self.films = {}
        for r in c.execute("SELECT * FROM Films"):
            self.films[r['Id']] = dict(id=r['Id'], title=r['Title'], year=r['Year'], runtime=r['RuntimeMinutes'],
                                       synopsis=r['Synopsis'], demo=bool(r['is_demo']), genres=[])
        for r in c.execute("SELECT * FROM FilmGenres"): self.films[r['FilmId']]['genres'].append(self.genres[r['GenreId']])
        self.users = {r['Id']: dict(id=r['Id'], name=r['DisplayName'], archetype=r['Archetype']) for r in c.execute("SELECT * FROM Users")}
        self.rating, self.viewed = defaultdict(dict), defaultdict(set)
        for r in c.execute("SELECT * FROM UserRatings"): self.rating[r['UserId']][r['FilmId']] = r['Score']
        for r in c.execute("SELECT * FROM ViewingHistories"): self.viewed[r['UserId']].add(r['FilmId'])
        c.close()

    # ---------- feature-uri
    def user_vector(self, u):
        gl = sorted(self.genres.values()); v = dict.fromkeys(gl, 0.0)
        for fid, s in self.rating[u].items():
            for g in self.films[fid]['genres']: v[g] += max(0, s - 2)       # apasa pe genurile apreciate
        t = sum(v.values()) or 1
        return [v[g] / t for g in gl]

    def film_features(self, fid):
        f = self.films[fid]; y = f['year']
        d = {f"gen:{g}": ('da' if g in f['genres'] else 'nu') for g in self.genres.values()}
        d['epoca'] = 'inainte-1990' if y < 1990 else '1990-1999' if y < 2000 else '2000-2009' if y < 2010 else 'dupa-2010'
        d['durata'] = 'scurt' if f['runtime'] < 100 else 'mediu' if f['runtime'] <= 140 else 'lung'
        d['popularitate'] = self.pop_band[fid]
        return d

    # ---------- antrenare globala (DBSCAN + Apriori)
    def fit(self):
        self.uids = sorted(self.users)
        vecs = [self.user_vector(u) for u in self.uids]
        self.labels = dict(zip(self.uids, dbscan(vecs, EPS, MIN_PTS)))
        self.clusters = defaultdict(list)
        for u, l in self.labels.items(): self.clusters[l].append(u)
        cnt = Counter(f for u in self.uids for f in self.viewed[u]); rk = sorted(self.films, key=lambda f: cnt[f])
        n = len(rk); self.pop_band = {f: ('mica' if i < n/3 else 'medie' if i < 2*n/3 else 'mare') for i, f in enumerate(rk)}
        self.popularity = cnt
        tx = [self.viewed[u] for u in self.uids if self.viewed[u]]
        self.freq, rules = apriori(tx, MIN_SUP, MIN_CONF, max_len=3)
        self.rules = [r for r in rules if r['lift'] >= MIN_LIFT]
        self.trees = {}

    def tree(self, u):
        if u not in self.trees:
            rows, y = [], []
            for fid, s in self.rating[u].items(): rows.append(self.film_features(fid)); y.append(int(s >= LIKE))
            self.trees[u] = ID3(max_depth=4, min_samples=4).fit(rows, y) if len(set(y)) > 1 else None
        return self.trees[u]

    # ---------- recomandare
    def recommend(self, u, k=10, hide=()):
        seen = (self.viewed[u] | set(self.rating[u])) - set(hide)
        cl = self.labels[u]; peers = [p for p in self.clusters[cl] if p != u] if cl != -1 else []
        cand = {}
        # 1) DBSCAN: filme apreciate de utilizatori din acelasi cluster
        if peers:
            like = Counter(f for p in peers for f, s in self.rating[p].items() if s >= LIKE)
            for f, c in like.items():
                if f not in seen: cand.setdefault(f, {})['cluster'] = c / len(peers)
        # 2) Apriori: reguli al caror antecedent e inclus in istoricul utilizatorului
        for r in self.rules:
            if set(r['antecedent']) <= seen:
                for f in r['consequent']:
                    if f not in seen:
                        d = cand.setdefault(f, {})
                        if r['confidence'] > d.get('apriori', 0):
                            d['apriori'] = r['confidence']
                            d['rule'] = f"{', '.join(self.films[a]['title'] for a in r['antecedent'])} -> {self.films[f]['title']}"
                            d['lift'] = r['lift']
        # 3) ID3: clasifica candidatii
        t = self.tree(u); out = []
        for f, d in cand.items():
            ft = self.film_features(f)
            p = t.predict_proba(ft) if t else 0.5
            score = W_ID3 * p + W_APR * d.get('apriori', 0) + W_CLU * d.get('cluster', 0)
            out.append(dict(film=self.films[f], score=round(score, 4), id3=round(p, 3),
                            apriori=round(d.get('apriori', 0), 3), cluster=round(d.get('cluster', 0), 3),
                            rule=d.get('rule'), lift=round(d.get('lift', 0), 2) if 'lift' in d else None,
                            id3_path=t.explain(ft) if t else [],
                            sources=[s for s in ('cluster', 'apriori') if d.get(s)]))
        out.sort(key=lambda r: -r['score'])
        return out[:k]

    def info(self):
        return dict(clusters={str(k): len(v) for k, v in sorted(self.clusters.items())},
                    n_rules=len(self.rules), n_freq=len(self.freq),
                    top_rules=[dict(r, antecedent=[self.films[a]['title'] for a in r['antecedent']],
                                    consequent=[self.films[a]['title'] for a in r['consequent']]) for r in self.rules[:8]])

    def evaluate(self, k=10):
        """Hold-out: ascunde 25% din filmele apreciate (>=4) ale fiecarui utilizator si masoara hit-rate@k vs. baseline popularitate."""
        import random; rnd = random.Random(7); hits = base = tot = 0
        for u in self.uids:
            liked = [f for f, s in self.rating[u].items() if s >= LIKE]
            if len(liked) < 4: continue
            hide = set(rnd.sample(liked, max(1, len(liked) // 4)))
            saved_r, saved_v = dict(self.rating[u]), set(self.viewed[u])
            for f in hide: self.rating[u].pop(f); self.viewed[u].discard(f)
            self.trees.pop(u, None)
            rec = {r['film']['id'] for r in self.recommend(u, k)}
            pops = [f for f, _ in self.popularity.most_common() if f not in self.viewed[u] and f not in self.rating[u]][:k]
            hits += len(rec & hide); base += len(set(pops) & hide); tot += len(hide)
            self.rating[u], self.viewed[u] = saved_r, saved_v; self.trees.pop(u, None)
        return dict(hits=hits, baseline=base, hidden=tot, recall_sistem=hits / tot, recall_baseline=base / tot)
